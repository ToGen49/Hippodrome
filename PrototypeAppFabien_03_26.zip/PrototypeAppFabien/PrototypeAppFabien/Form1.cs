﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json.Serialization;
using System.Text.Json;

namespace PrototypeAppFabien
{
    public partial class Pageprincipale : Form
    {
        public Pageprincipale()
        {
            InitializeComponent();

            gdtmpDateDeDebut.Value = DateTime.Now.Subtract(new TimeSpan(15,0,0,0));

            CAPI gobjCAPI = new CAPI();
            CTemperatureAir gobjCTemperatureAir = new CTemperatureAir(gobjCAPI);
            //glblTemperatureAir.Text = String.Concat("Température air : ",glstobjCJsonMeteo[0].mfltValeur.ToString(), " °C");
        }

        private void glblRajouterDateArrosage_MouseClick(object sender, MouseEventArgs e)
        {
            //OUVRIR NOUVELLE PAGE COMME PR DP OBSERVEUR
        }
    }
}
