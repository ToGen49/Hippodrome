﻿/*

CInfoMeteo.cs

Auteur : Fabien DAVID
Date de création : 21/03/2025, 10:49
Dernière modification : 21/03/2025, 10:49
Justification : X

Classe implémentant ICInfoGenerale
Elle va agir comme une classe contrôle.
Elle se charge de communiquer avec les objets CAPI et CJsonMeteo.
Ses héritiés ne seront spécialisé sur un seul type d'information météorologique

*/

using PrototypeAppFabien;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using PrototypeAppFabien.Properties;
using System.Text.Json;

namespace PrototypeAppFabien
{
    public class CInfoMeteo : ICInfoGenerale
    {
        
        protected String mstrDataType;
        protected CAPI mobjCAPI;
        protected List<CJsonMeteo> mlstobjCJsonMeteo;
        protected CJsonMeteo mobjCJsonMeteoValeurRecente;

        public CInfoMeteo()
        {
            mstrDataType = "NonDefinit";
            mobjCJsonMeteoValeurRecente = new CJsonMeteo();
            //On met la date la plus ancienne du type
            mobjCJsonMeteoValeurRecente.mdtmDate = new DateTime(DateTime.MinValue.Year, DateTime.MinValue.Month, DateTime.MinValue.Day);
            mobjCJsonMeteoValeurRecente.mfltValeur = (float) new Decimal(0.000);
        }

        public CInfoMeteo(CAPI objCAPI) 
        { 
            mstrDataType = "NonDefinit";
            mobjCAPI = objCAPI;
        }

        ~CInfoMeteo(){
            //La liste CJsonMeteo ne compose plus l'objet
            mlstobjCJsonMeteo = null;
        }

        String ICInfoGenerale.mstrGetDataType(){  return mstrDataType; }
        int ICInfoGenerale.mintfunSetAgreCAPI(CAPI objCAPI) 
        {
            mobjCAPI = objCAPI;
            return 0; 
        }
        //public float mfltfunGetmfltValeurRecente() {  return mfltValeurRecente; }

        public void mvfunSetmlstobjCJsonMeteo(DateTime dtmDateDeDebut, DateTime dtmDateDeFin)
        {
            /*
             * mvfunSetmlstobjCJsonMeteo(DateTime dtmDateDeDebut, DateTime dtmDateDeFin)
             *  dtmDateDeDebut  : Date de la donnée la plus ancienne souhaitée (exemple : 09/09/2025)
             *  dtmDateDeFin    : Date de la donnée la plus récente souhaitée (exemple : 13/09/2025)
             *
             * La méthode calcule un paramètre, la fréquence
             *  La fréquence indique l'espace de temps en heure entre chaque données
             *  Une fréquence de 3 veut dire que l'on a 8 données en 24h
             *  
             * elle transmet les paramètres à CAPI pour former et envoyer la requête
             * 
             * Enfin, elle passe en plus en paramètre son mstrDataType pour préciser
             * quel est son type de données
             *  mstrDataType n'a pas de set, elle est seulement modifiée dans les constructeurs
             *  des héritiés de CInfoMeteo
             *  
             * Ensuite, elle récupère le retour, c'est un json sous forme de string
             * 
             * Elle deserialise se string en une liste d'objet CJsonMeteo
             */

            short shtfrequence;
            TimeSpan tmsTimespan;

            #region Calcul de shtfrequence
            // Difference entre la date de début et la date de fin
            tmsTimespan = dtmDateDeFin.Subtract(dtmDateDeDebut);

            /*
             * On veut une information toute les shtfrequence d'heure
             * Elle peut être plus ou moins élevée selon la période de temps sélectionnée
             * Cette fréquence doit être inférieur ou égale à 12
             * Cette fréquence doit être un multiple de 24
             * 
             * On prend le nombre de jour de la
             * difference entre la date de début et la date de fin sélectionnées
             * Puis on lui fait une division euclidienne par 7
             * On lui rajoute 1
             * Cela nous donne la fréquence
             */
            shtfrequence = (short)((tmsTimespan.Days/7) + 1);

            //On s'assure que la fréquence ne dépasse pas 12
            if (shtfrequence > 12)
                shtfrequence = 12;

            //Les multiples de 24 sont : 1,2,3,4,6,8,12
            //Si shtfrequence n'est pas égale à l'une de ces valeurs, alors on la force
            switch (shtfrequence)
            {
                case 5:
                    shtfrequence = 4;
                    break;

                case 7:
                    shtfrequence = 6;
                    break;

                case 9:
                    shtfrequence = 8;
                    break;

                case 10:
                    shtfrequence = 12;
                    break;

                case 11:
                    shtfrequence = 12;
                    break;

                default:
                    break;
            }

            /* Avec ces calculs, on peut établir le nombre de valeur par jour selon la durée
             *
             *  Différence de jour  :   Valeur par jour
             *          0 - 6       :   24
             *          7 - 13      :   12
             *          14 - 20     :   8
             *          21 - 34     :   6
             *          35 - 48     :   4
             *          49 - 62     :   3
             *          x > 62      :   2
             */

            #endregion

            mobjCAPI.mintfunWriteDdeQuerry(
                mstrDataType,
                dtmDateDeDebut,
                dtmDateDeFin,
                shtfrequence
                );

            //Envoi de la demande et réception
            String strRawJsonString = mobjCAPI.mstrfunSendGetQuerry();
            //Conversion de la réception en liste d'objet CJsonMeteo
            mlstobjCJsonMeteo = JsonSerializer.Deserialize<List<CJsonMeteo>>(strRawJsonString);

            //Si on reçoit une valeur plus récente que mobjCJsonMeteoValeurRecente
            //Alors mobjCJsonMeteoValeurRecente prend la valeur et la date
            if (mlstobjCJsonMeteo[0].mdtmDate >= mobjCJsonMeteoValeurRecente.mdtmDate)
                mobjCJsonMeteoValeurRecente = mlstobjCJsonMeteo[0];
        }
    }


}
