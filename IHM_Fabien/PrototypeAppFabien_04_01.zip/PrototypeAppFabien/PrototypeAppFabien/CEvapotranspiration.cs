﻿/*

CEvapotranspiration.cs

Auteur : Fabien DAVID
Date de création : 31/03/2025, 08:22
Dernière modification : 31/03/2025, 08:22
Justification : X

Classe CEvapotranspiration hérite de CInfoMeteo
La donnée de l'évapotranspiration est un calcul, elle n'est pas fournie par l'API
Le calcul nécéssite plusieurs données fournie par l'API
Elle agit donc comme une classe controle

*/

using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrototypeAppFabien
{
    internal class CEvapotranspiration : CInfoMeteo
    {
        private CTemperatureAir mobjCTemperatureAir;
        private CHygrometrie mobjCHygrometrie;
        private CVitesseVent mobjCVitesseVent;
        private CEnsoleillement mobjCEnsoleillement;
        private float mfltAlbedo = 0.23F; // Albedo de l'hippodrome concerné, peut être changé
        private float mfltAltitude = 46.8F; // Altitude de l'hippodrome concerné, peut être changé

        #region Constructeurs et destructeur de classe
        public CEvapotranspiration() {}
        public CEvapotranspiration(CAPI objCAPI) : base (objCAPI) { }
        public CEvapotranspiration(
                    CAPI objCAPI,
                    CTemperatureAir objCTemperatureAir,
                    CHygrometrie objCHygrometrie,
                    CVitesseVent objCVitesseVent,
                    CEnsoleillement objCEnsoleillement
                    ) : base(objCAPI) 
        { 
            this.mobjCTemperatureAir = objCTemperatureAir;
            this.mobjCHygrometrie = objCHygrometrie;
            this.mobjCVitesseVent = objCVitesseVent;
            this.mobjCEnsoleillement = objCEnsoleillement;
        }

        ~CEvapotranspiration() { }
        #endregion

        #region Méthodes liés aux associations
        public int intfunsetAssoCTemperatureAir(CTemperatureAir objCTemperatureAir)
        {
            this.mobjCTemperatureAir = objCTemperatureAir;
            return 0;
        }

        public int intfunsetAssoCHygrometrie(CHygrometrie objCHygrometrie)
        {
            this.mobjCHygrometrie = objCHygrometrie;
            return 0;
        }

        public int intfunsetAssoCVitesseVent(CVitesseVent objCVitesseVent)
        {
            this.mobjCVitesseVent = objCVitesseVent;
            return 0;
        }
        public int intfunsetAssoCEnsoleillement(CEnsoleillement objCEnsoleillement)
        {
            this.mobjCEnsoleillement = objCEnsoleillement;
            return 0;
        }
        #endregion

        #region get et set des attributs
        public float mfltfungetmfltAlbedo() { return this.mfltAlbedo; }
        public void mvfunsetmfltAlbedo(float fltAlbedo) { this.mfltAlbedo = fltAlbedo; }

        public float mfltfungetmfltAltitude() {  return this.mfltAltitude; }
        public void mvfunsetmfltAltitude(float fltAltitude) {  this.mfltAltitude = fltAltitude; }
        #endregion

        public float mfltCalculEvapotranspiration(DateTime dtmDateDeDebut, DateTime dtmDateDeFin)
        {
            //Element à renvoyer
            float fltEvapotranspiration;

            //Si L'evapotranspiration n'est pas calculée, la méthode renvoie une valeur impossible
            fltEvapotranspiration = -1.0F;

            //La période de calcul de l'évapotranspiration est de minimum un jour
            TimeSpan tmsDateDebutFin;
            tmsDateDebutFin = new TimeSpan();
            tmsDateDebutFin = dtmDateDeFin.Subtract(dtmDateDeDebut);

            if (tmsDateDebutFin.Days > 0)
            {
                #region Déclaration des variables de méthodes
                //Moyennes utilisées dans le calcul
                float fltMoyenneTemperatureAir;
                float fltMoyenneHygrometrie;
                float fltMoyenneVitesseVent;
                float fltMoyenneEnsoleillement;

                //Constantes
                //Modifiable ici ou dans le constructeur de classe CEvapotranspiration
                float Albedo = mfltAlbedo; //Si non modifiée, 0.23
                float Altitude = mfltAltitude; // Si non modifiée, 48.6 (mètre)

                //Sous calcul utilisant les moyennes et autres constantes
                float fltMoyenneVitesseVent2m;
                float fltRGNet;
                float fltPressionVapeurSaturee;
                float fltPressionVapeurEffective;
                float fltPenteCourbePressionVapeurSaturee;
                float fltPressionAtmospherique;
                float fltConstantePsychometrique;
                #endregion

                #region Calcul des moyennes
                fltMoyenneTemperatureAir = this.mobjCTemperatureAir.mfltfunCalculMoyenne(dtmDateDeDebut, dtmDateDeFin);
                fltMoyenneHygrometrie = this.mobjCHygrometrie.mfltfunCalculMoyenne(dtmDateDeDebut, dtmDateDeFin);
                fltMoyenneVitesseVent = this.mobjCVitesseVent.mfltfunCalculMoyenne(dtmDateDeDebut, dtmDateDeFin);
                fltMoyenneEnsoleillement = this.mobjCEnsoleillement.mfltfunCalculMoyenne(dtmDateDeDebut, dtmDateDeFin);



                // A ENELEVER
                fltMoyenneVitesseVent = 3.3333F;
                fltMoyenneEnsoleillement = 1367F / 11.575F; //Conversion em MJ/m²/j
                fltMoyenneHygrometrie = 0.5F;
                fltMoyenneTemperatureAir = 12.31F;

                #endregion

                #region Calcul des sous calculs
                fltMoyenneVitesseVent2m = fltMoyenneVitesseVent;
                //fltMoyenneVitesseVent2m = fltMoyenneVitesseVent * 0.7; //Enlever commentaire sur la vitesse du vent est prélevée à 10m du sol
                
                fltRGNet = 1F - Albedo;
                fltRGNet = fltMoyenneEnsoleillement * fltRGNet;

                fltPressionVapeurSaturee = 17.27F * fltMoyenneTemperatureAir;
                float diviseur = 273.3F + fltMoyenneTemperatureAir;
                fltPressionVapeurSaturee = fltPressionVapeurSaturee / diviseur;
                fltPressionVapeurSaturee = 0.6108F * (float)Math.Exp(fltPressionVapeurSaturee);

                fltPressionVapeurEffective = fltPressionVapeurSaturee * fltMoyenneHygrometrie / 100F ;

                diviseur = (float)Math.Pow((273.3F + fltMoyenneTemperatureAir), 2F);
                fltPenteCourbePressionVapeurSaturee = 4098F * fltPressionVapeurSaturee / diviseur;

                fltPressionAtmospherique = 0.0065F * Altitude;
                fltPressionAtmospherique = 293F - fltPressionAtmospherique;
                fltPressionAtmospherique = fltPressionAtmospherique / 293F;
                fltPressionAtmospherique = 101.3F * (float)Math.Pow(fltPressionAtmospherique, 5.26F);

                fltConstantePsychometrique = 0.665F * fltPressionAtmospherique * (float)Math.Pow(10F, -3F);

                #endregion

                #region Le calcul de l'evapotranspiration

                float division1 = fltMoyenneTemperatureAir + 273F;
                float soustraction1 = fltPressionVapeurSaturee - fltPressionVapeurEffective;
                float division2 = fltPenteCourbePressionVapeurSaturee;
                float division3 = 1F + 0.34F * fltMoyenneVitesseVent;
                float division4 = fltConstantePsychometrique * division3;
                float division5 = division2 + division4;

                fltEvapotranspiration =
                    0.408F *
                    fltPenteCourbePressionVapeurSaturee *
                    fltRGNet +
                    fltConstantePsychometrique /
                    division1 *
                    fltMoyenneVitesseVent *
                    soustraction1 /
                    division5;





                #endregion

            }
            else
            { 
                Console.WriteLine("Période de données pas assez grande");
                //Si L'evapotranspiration n'est pas calculée, la méthode renvoie une valeur impossible
                fltEvapotranspiration = -1.0F;
            }

            return fltEvapotranspiration;
        }

    }
}
