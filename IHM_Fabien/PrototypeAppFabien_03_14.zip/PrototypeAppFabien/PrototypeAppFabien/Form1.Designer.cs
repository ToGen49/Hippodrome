﻿namespace PrototypeAppFabien
{
    partial class Pageprincipale
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblnomhippodrome = new System.Windows.Forms.Label();
            this.lblpluviometrie = new System.Windows.Forms.Label();
            this.lbltemperatureair = new System.Windows.Forms.Label();
            this.lblhygrometrie = new System.Windows.Forms.Label();
            this.lblvitessevent = new System.Windows.Forms.Label();
            this.lblevapotranspiration = new System.Windows.Forms.Label();
            this.lblexplicationpluviometrie = new System.Windows.Forms.Label();
            this.lblexplicationtemperatureair = new System.Windows.Forms.Label();
            this.lblexplicationhygrometrie = new System.Windows.Forms.Label();
            this.lblexplicationvitessevent = new System.Windows.Forms.Label();
            this.lblexplicationevapotranspiration = new System.Windows.Forms.Label();
            this.lbldirectionvent = new System.Windows.Forms.Label();
            this.lblexplicationdirectionvent = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::PrototypeAppFabien.Properties.Resources.fond_papier_bleu_foto_blue___125_bd_p_image_51530_grande;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1924, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblnomhippodrome
            // 
            this.lblnomhippodrome.AccessibleDescription = "";
            this.lblnomhippodrome.AccessibleName = "";
            this.lblnomhippodrome.AutoSize = true;
            this.lblnomhippodrome.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnomhippodrome.Location = new System.Drawing.Point(770, 53);
            this.lblnomhippodrome.Name = "lblnomhippodrome";
            this.lblnomhippodrome.Size = new System.Drawing.Size(474, 37);
            this.lblnomhippodrome.TabIndex = 2;
            this.lblnomhippodrome.Tag = "";
            this.lblnomhippodrome.Text = "Hippodrome Angers-Ecouflant";
            // 
            // lblpluviometrie
            // 
            this.lblpluviometrie.AutoSize = true;
            this.lblpluviometrie.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpluviometrie.Location = new System.Drawing.Point(58, 144);
            this.lblpluviometrie.Name = "lblpluviometrie";
            this.lblpluviometrie.Size = new System.Drawing.Size(298, 31);
            this.lblpluviometrie.TabIndex = 3;
            this.lblpluviometrie.Text = "Pluviométrie : XX.X mm";
            this.lblpluviometrie.MouseLeave += new System.EventHandler(this.lblpluviometrie_MouseLeave);
            this.lblpluviometrie.MouseHover += new System.EventHandler(this.lblpluviometrie_MouseHover);
            // 
            // lbltemperatureair
            // 
            this.lbltemperatureair.AutoSize = true;
            this.lbltemperatureair.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltemperatureair.Location = new System.Drawing.Point(58, 202);
            this.lbltemperatureair.Name = "lbltemperatureair";
            this.lbltemperatureair.Size = new System.Drawing.Size(328, 31);
            this.lbltemperatureair.TabIndex = 4;
            this.lbltemperatureair.Text = "Température air : XX.X °C";
            this.lbltemperatureair.MouseLeave += new System.EventHandler(this.lbltemperatureair_MouseLeave);
            this.lbltemperatureair.MouseHover += new System.EventHandler(this.lbltemperatureair_MouseHover);
            // 
            // lblhygrometrie
            // 
            this.lblhygrometrie.AutoSize = true;
            this.lblhygrometrie.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhygrometrie.Location = new System.Drawing.Point(58, 259);
            this.lblhygrometrie.Name = "lblhygrometrie";
            this.lblhygrometrie.Size = new System.Drawing.Size(251, 31);
            this.lblhygrometrie.TabIndex = 5;
            this.lblhygrometrie.Text = "Hygrométrie : XX %";
            this.lblhygrometrie.MouseLeave += new System.EventHandler(this.lblhygrometrie_MouseLeave);
            this.lblhygrometrie.MouseHover += new System.EventHandler(this.lblhygrometrie_MouseHover);
            // 
            // lblvitessevent
            // 
            this.lblvitessevent.AutoSize = true;
            this.lblvitessevent.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvitessevent.Location = new System.Drawing.Point(58, 326);
            this.lblvitessevent.Name = "lblvitessevent";
            this.lblvitessevent.Size = new System.Drawing.Size(287, 31);
            this.lblvitessevent.TabIndex = 6;
            this.lblvitessevent.Text = "Vitesse vent : XX km/h";
            this.lblvitessevent.MouseLeave += new System.EventHandler(this.lblvitessevent_MouseLeave);
            this.lblvitessevent.MouseHover += new System.EventHandler(this.lblvitessevent_MouseHover);
            // 
            // lblevapotranspiration
            // 
            this.lblevapotranspiration.AutoSize = true;
            this.lblevapotranspiration.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblevapotranspiration.Location = new System.Drawing.Point(58, 390);
            this.lblevapotranspiration.Name = "lblevapotranspiration";
            this.lblevapotranspiration.Size = new System.Drawing.Size(408, 31);
            this.lblevapotranspiration.TabIndex = 7;
            this.lblevapotranspiration.Text = "Evapotranspiration : XX.XX mm/j";
            this.lblevapotranspiration.MouseLeave += new System.EventHandler(this.lblevapotranspiration_MouseLeave);
            this.lblevapotranspiration.MouseHover += new System.EventHandler(this.lblevapotranspiration_MouseHover);
            // 
            // lblexplicationpluviometrie
            // 
            this.lblexplicationpluviometrie.AutoSize = true;
            this.lblexplicationpluviometrie.BackColor = System.Drawing.SystemColors.Info;
            this.lblexplicationpluviometrie.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblexplicationpluviometrie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexplicationpluviometrie.Location = new System.Drawing.Point(362, 133);
            this.lblexplicationpluviometrie.Name = "lblexplicationpluviometrie";
            this.lblexplicationpluviometrie.Size = new System.Drawing.Size(235, 42);
            this.lblexplicationpluviometrie.TabIndex = 8;
            this.lblexplicationpluviometrie.Text = "Pluviométrie prélevée la [DATE].\n1mm = 1L/m²";
            this.lblexplicationpluviometrie.Visible = false;
            // 
            // lblexplicationtemperatureair
            // 
            this.lblexplicationtemperatureair.AutoSize = true;
            this.lblexplicationtemperatureair.BackColor = System.Drawing.SystemColors.Info;
            this.lblexplicationtemperatureair.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblexplicationtemperatureair.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexplicationtemperatureair.Location = new System.Drawing.Point(392, 211);
            this.lblexplicationtemperatureair.Name = "lblexplicationtemperatureair";
            this.lblexplicationtemperatureair.Size = new System.Drawing.Size(262, 22);
            this.lblexplicationtemperatureair.TabIndex = 9;
            this.lblexplicationtemperatureair.Text = "Température air prélevée le [DATE].";
            this.lblexplicationtemperatureair.Visible = false;
            // 
            // lblexplicationhygrometrie
            // 
            this.lblexplicationhygrometrie.AutoSize = true;
            this.lblexplicationhygrometrie.BackColor = System.Drawing.SystemColors.Info;
            this.lblexplicationhygrometrie.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblexplicationhygrometrie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexplicationhygrometrie.Location = new System.Drawing.Point(315, 268);
            this.lblexplicationhygrometrie.Name = "lblexplicationhygrometrie";
            this.lblexplicationhygrometrie.Size = new System.Drawing.Size(236, 22);
            this.lblexplicationhygrometrie.TabIndex = 10;
            this.lblexplicationhygrometrie.Text = "Hygrométrie prélevée le [DATE].";
            this.lblexplicationhygrometrie.Visible = false;
            // 
            // lblexplicationvitessevent
            // 
            this.lblexplicationvitessevent.AutoSize = true;
            this.lblexplicationvitessevent.BackColor = System.Drawing.SystemColors.Info;
            this.lblexplicationvitessevent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblexplicationvitessevent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexplicationvitessevent.Location = new System.Drawing.Point(351, 335);
            this.lblexplicationvitessevent.Name = "lblexplicationvitessevent";
            this.lblexplicationvitessevent.Size = new System.Drawing.Size(259, 22);
            this.lblexplicationvitessevent.TabIndex = 11;
            this.lblexplicationvitessevent.Text = "Vitesse du vent prélevée le [DATE].";
            this.lblexplicationvitessevent.Visible = false;
            this.lblexplicationvitessevent.MouseLeave += new System.EventHandler(this.lblexplicationvitessevent_MouseLeave);
            this.lblexplicationvitessevent.MouseHover += new System.EventHandler(this.label1_MouseHover);
            // 
            // lblexplicationevapotranspiration
            // 
            this.lblexplicationevapotranspiration.AutoSize = true;
            this.lblexplicationevapotranspiration.BackColor = System.Drawing.SystemColors.Info;
            this.lblexplicationevapotranspiration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblexplicationevapotranspiration.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexplicationevapotranspiration.Location = new System.Drawing.Point(472, 336);
            this.lblexplicationevapotranspiration.Name = "lblexplicationevapotranspiration";
            this.lblexplicationevapotranspiration.Size = new System.Drawing.Size(316, 122);
            this.lblexplicationevapotranspiration.TabIndex = 12;
            this.lblexplicationevapotranspiration.Text = "Evapotranspiration calculée avec la formule\nde Penman Monteith qui nécissite :\n- " +
    "Température air\n- Hygrométrie\n- Vitesse vent\n- Ensoleillement";
            this.lblexplicationevapotranspiration.Visible = false;
            // 
            // lbldirectionvent
            // 
            this.lbldirectionvent.AutoSize = true;
            this.lbldirectionvent.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldirectionvent.Location = new System.Drawing.Point(58, 458);
            this.lbldirectionvent.Name = "lbldirectionvent";
            this.lbldirectionvent.Size = new System.Drawing.Size(239, 31);
            this.lbldirectionvent.TabIndex = 13;
            this.lbldirectionvent.Text = "Direction vent : XX";
            this.lbldirectionvent.MouseLeave += new System.EventHandler(this.lbldirectionvent_MouseLeave);
            this.lbldirectionvent.MouseHover += new System.EventHandler(this.lbldirectionvent_MouseHover);
            // 
            // lblexplicationdirectionvent
            // 
            this.lblexplicationdirectionvent.AutoSize = true;
            this.lblexplicationdirectionvent.BackColor = System.Drawing.SystemColors.Info;
            this.lblexplicationdirectionvent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblexplicationdirectionvent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexplicationdirectionvent.Location = new System.Drawing.Point(303, 445);
            this.lblexplicationdirectionvent.Name = "lblexplicationdirectionvent";
            this.lblexplicationdirectionvent.Size = new System.Drawing.Size(267, 62);
            this.lblexplicationdirectionvent.TabIndex = 14;
            this.lblexplicationdirectionvent.Text = "Direction du vent mesurée le [DATE]\nLa direction utilise les abréviations\ndes poi" +
    "nts cardinaux";
            this.lblexplicationdirectionvent.Visible = false;
            // 
            // Pageprincipale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1904, 1041);
            this.Controls.Add(this.lblexplicationdirectionvent);
            this.Controls.Add(this.lbldirectionvent);
            this.Controls.Add(this.lblexplicationevapotranspiration);
            this.Controls.Add(this.lblexplicationvitessevent);
            this.Controls.Add(this.lblexplicationhygrometrie);
            this.Controls.Add(this.lblexplicationtemperatureair);
            this.Controls.Add(this.lblexplicationpluviometrie);
            this.Controls.Add(this.lblevapotranspiration);
            this.Controls.Add(this.lblvitessevent);
            this.Controls.Add(this.lblhygrometrie);
            this.Controls.Add(this.lbltemperatureair);
            this.Controls.Add(this.lblpluviometrie);
            this.Controls.Add(this.lblnomhippodrome);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Pageprincipale";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblnomhippodrome;
        private System.Windows.Forms.Label lblpluviometrie;
        private System.Windows.Forms.Label lbltemperatureair;
        private System.Windows.Forms.Label lblhygrometrie;
        private System.Windows.Forms.Label lblvitessevent;
        private System.Windows.Forms.Label lblevapotranspiration;
        private System.Windows.Forms.Label lblexplicationpluviometrie;
        private System.Windows.Forms.Label lblexplicationtemperatureair;
        private System.Windows.Forms.Label lblexplicationhygrometrie;
        private System.Windows.Forms.Label lblexplicationvitessevent;
        private System.Windows.Forms.Label lblexplicationevapotranspiration;
        private System.Windows.Forms.Label lbldirectionvent;
        private System.Windows.Forms.Label lblexplicationdirectionvent;
    }
}

