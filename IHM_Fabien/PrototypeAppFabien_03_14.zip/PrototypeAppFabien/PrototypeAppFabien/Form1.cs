﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototypeAppFabien
{
    public partial class Pageprincipale : Form
    {
        public Pageprincipale()
        {
            InitializeComponent();
        }

        private void lblpluviometrie_MouseHover(object sender, EventArgs e)
        {
            this.lblexplicationpluviometrie.Visible = true;
        }

        private void lblpluviometrie_MouseLeave(object sender, EventArgs e)
        {
            this.lblexplicationpluviometrie.Visible = false;
        }

        private void lbltemperatureair_MouseHover(object sender, EventArgs e)
        {
            this.lblexplicationtemperatureair.Visible = true;
        }

        private void lbltemperatureair_MouseLeave(object sender, EventArgs e)
        {
            this.lblexplicationtemperatureair.Visible = false;
        }

        private void lblhygrometrie_MouseHover(object sender, EventArgs e)
        {
            this.lblexplicationhygrometrie.Visible = true;
        }

        private void lblhygrometrie_MouseLeave(object sender, EventArgs e)
        {
            this.lblexplicationhygrometrie.Visible= false;
        }

        private void label1_MouseHover(object sender, EventArgs e)
        {
            this.lblexplicationvitessevent.Visible = true;
        }

        private void lblexplicationvitessevent_MouseLeave(object sender, EventArgs e)
        {
            this.lblexplicationvitessevent.Visible= false;
        }

        private void lblvitessevent_MouseHover(object sender, EventArgs e)
        {
            this.lblexplicationvitessevent.Visible= true;
        }

        private void lblvitessevent_MouseLeave(object sender, EventArgs e)
        {
            this.lblexplicationvitessevent.Visible=false;
        }

        private void lblevapotranspiration_MouseHover(object sender, EventArgs e)
        {
            this.lblexplicationevapotranspiration.Visible = true;
        }

        private void lblevapotranspiration_MouseLeave(object sender, EventArgs e)
        {
            this.lblexplicationevapotranspiration.Visible = false;
        }

        private void lbldirectionvent_MouseHover(object sender, EventArgs e)
        {
            this.lblexplicationdirectionvent.Visible = true;
        }

        private void lbldirectionvent_MouseLeave(object sender, EventArgs e)
        {
            this.lblexplicationdirectionvent.Visible= false;
        }
    }
}
