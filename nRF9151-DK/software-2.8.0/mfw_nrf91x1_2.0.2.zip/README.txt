Full modem wired and Full modem FOTA updates can be performed using the modem firmware in CBOR image
format, provided that you have the necessary support from the nRF Connect SDK and the device
hardware. The filename is as follows:
- mfw_nrf91x1_2.0.2.cbor

This release version includes delta update from the previous firmware version. The FOTA update
filename is as follows:
- mfw_nrf91x1_update_from_2.0.1_to_2.0.2.bin

Additionally, this release includes FOTA-TEST delta update images between the original firmware and
the FOTA-TEST image. The FOTA test update filenames are as follows:
- mfw_nrf91x1_update_from_2.0.2_to_2.0.2-FOTA-TEST
- mfw_nrf91x1_update_from_2.0.2-FOTA-TEST_to_2.0.2
- mfw_nrf91x1_large_update_from_2.0.2_to_2.0.2-FOTA-TEST.bin
- mfw_nrf91x1_large_update_from_2.0.2-FOTA-TEST_to_2.0.2.bin
 
UUID of mfw_nrf91x1_2.0.2 is 320176d5-9f40-45fc-923b-2661ec18d547
UUID of mfw_nrf91x1_2.0.2-FOTA-TEST is 8265da3c-ab9d-44b2-bbec-b1650c7c5a99